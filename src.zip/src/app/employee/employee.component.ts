import { Component } from '@angular/core';

@Component({
  selector: 'app-employee',
  templateUrl: './employee.component.html',
  styleUrls: ['./employee.component.css']
})
export class EmployeeComponent {
  // Define position names
  positionNames: ('Technician' | 'Specialist' | 'Manager' | 'Director')[] = [
    'Technician', 'Specialist', 'Manager', 'Director'
  ];

  // Employee data model
  employee = {
    name: '',
    email: '',
    position: '' as 'Technician' | 'Specialist' | 'Manager' | 'Director', 
    service: '',
    number: '', // To store assigned number
    internetPackage: '' // To store assigned internet package
  };

  // Employees grouped by position
  positionEmployees: Record<'Technician' | 'Specialist' | 'Manager' | 'Director', { name: string; email: string; service: string; number: string; internetPackage: string }[]> = {
    Technician: [],
    Specialist: [],
    Manager: [],
    Director: []
  };

  // List of available numbers and internet packages
  availableNumbers: string[] = ['1001', '1002', '1003', '1004', '1005'];
  internetPackages: Record<'Technician' | 'Specialist' | 'Manager' | 'Director', string[]> = {
    Technician: ['Basic', 'Standard'],
    Specialist: ['Standard', 'Premium'],
    Manager: ['Premium', 'Business'],
    Director: ['Business', 'Enterprise']
  };

  // Method to add an employee
  addEmployee() {
    const selectedPosition: 'Technician' | 'Specialist' | 'Manager' | 'Director' = this.employee.position;

    // Automatically assign a number and internet package based on position
    const assignedNumber = this.assignNumber();
    const assignedPackage = this.assignPackage(selectedPosition);

    // Update the employee object with the assigned number and package
    this.employee.number = assignedNumber;
    this.employee.internetPackage = assignedPackage;

    // Add the employee to the list of employees by position
    if (this.positionEmployees[selectedPosition]) {
      this.positionEmployees[selectedPosition].push({
        name: this.employee.name,
        email: this.employee.email,
        service: this.employee.service,
        number: this.employee.number,
        internetPackage: this.employee.internetPackage
      });
    }

    // Clear the form after adding
    this.employee = { name: '', email: '', position: '' as 'Technician' | 'Specialist' | 'Manager' | 'Director', service: '', number: '', internetPackage: '' };
  }

  // Assign a number to the employee
  assignNumber(): string {
    return this.availableNumbers.shift() || ''; // Get the first available number and remove it from the list
  }

  // Assign an internet package based on the position
  assignPackage(position: 'Technician' | 'Specialist' | 'Manager' | 'Director'): string {
    const packages = this.internetPackages[position];
    const randomIndex = Math.floor(Math.random() * packages.length);
    return packages[randomIndex]; // Randomly select a package for the position
  }
}
