import { Component, EventEmitter, Output } from '@angular/core';

@Component({
  selector: 'app-add-employee',
  templateUrl: './add-employee.component.html',
  styleUrls: ['./add-employee.component.css']
})
export class AddEmployeeComponent {
  @Output() employeeAdded = new EventEmitter<any>();

  positionNames: ('Technician' | 'Specialist' | 'Manager' | 'Director')[] = [
    'Technician', 'Specialist', 'Manager', 'Director'
  ];

  employee = {
    name: '',
    email: '',
    position: '' as 'Technician' | 'Specialist' | 'Manager' | 'Director',
    service: ''
  };

  onSubmit() {
    this.employeeAdded.emit(this.employee);
    this.employee = { name: '', email: '', position: '' as 'Technician' | 'Specialist' | 'Manager' | 'Director', service: '' };
  }
}
