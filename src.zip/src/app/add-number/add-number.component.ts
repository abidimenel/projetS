import { Component } from '@angular/core';

@Component({
  selector: 'app-add-number',
  templateUrl: './add-number.component.html',
  styleUrls: ['./add-number.component.css']
})
export class AddNumberComponent {
  newNumber: string = '';
  availableNumbers: string[] = [];

  addNumber() {
    if (this.newNumber && !this.availableNumbers.includes(this.newNumber)) {
      this.availableNumbers.push(this.newNumber);
      this.newNumber = '';
    }
  }
}
