import { Component, OnInit } from '@angular/core';
import { EmployeeService } from '../employee.service';

@Component({
  selector: 'app-employee-list',
  templateUrl: './employee-list.component.html',
  styleUrls: ['./employee-list.component.css'],
})
export class EmployeeListComponent implements OnInit {
  employees: any[] = [];
  filteredEmployees: any[] = [];
  searchQuery: string = '';
  filterOption: string = ''; // 'withNumber' ou 'withoutNumber'
  isFilterMenuOpen: boolean = false;

  constructor(private employeeService: EmployeeService) {}

  ngOnInit(): void {
    // Utiliser le service pour récupérer les employés depuis le backend
    this.employeeService.getAllEmployees().subscribe(
      (data) => {
        this.employees = data; // Stocker les données dans la variable employees
        this.filteredEmployees = data; // Initialiser avec tous les employés
      },
      (error) => {
        console.error('Erreur lors de la récupération des employés', error);
      }
    );
  }

  /**
   * Filtrer les employés selon la recherche et les options de filtre.
   */
  filterEmployees(): void {
    let filtered = this.employees.filter((employee) => {
      const query = this.searchQuery.toLowerCase();
      return (
        employee.nom.toLowerCase().includes(query) ||
        employee.cin.toLowerCase().includes(query) ||
        (employee.dateAttribution && employee.dateAttribution.toLowerCase().includes(query))
      );
    });

    // Appliquer le filtre par numéro de téléphone
    if (this.filterOption === 'withNumber') {
      filtered = filtered.filter((employee) => employee.numTelephone);
    } else if (this.filterOption === 'withoutNumber') {
      filtered = filtered.filter((employee) => !employee.numTelephone);
    }

    // Trier par date d'attribution puis par nom
    filtered.sort((a, b) => {
      if (a.dateAttribution === b.dateAttribution) {
        return a.nom.localeCompare(b.nom);
      }
      return new Date(a.dateAttribution).getTime() - new Date(b.dateAttribution).getTime();
    });

    this.filteredEmployees = filtered;
  }

  /**
   * Ouvrir ou fermer le menu de filtre.
   */
  toggleFilterMenu(): void {
    this.isFilterMenuOpen = !this.isFilterMenuOpen;
  }

  /**
   * Définir l'option de filtre.
   * @param option L'option de filtre choisie (avec numéro ou sans numéro).
   */
  setFilterOption(option: string): void {
    this.filterOption = option;
    this.filterEmployees(); // Appliquer immédiatement le filtre
    this.isFilterMenuOpen = false; // Fermer le menu
  }
}
