import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { SimService } from '../sim.service';
import { EmployeeService } from '../employee.service';

@Component({
  selector: 'app-assign-sim',
  templateUrl: './assign-sim.component.html',
  styleUrls: ['./assign-sim.component.css'],
})
export class AssignSimComponent implements OnInit {
  assignForm: FormGroup;
  employees: any[] = [];
  assignedData: any = {}; // Stocke les données de la SIM attribuée
  showModal: boolean = false; // Contrôle la visibilité de la modale

  constructor(
    private fb: FormBuilder,
    private simService: SimService,
    private employeeService: EmployeeService
  ) {
    this.assignForm = this.fb.group({
      employeeId: ['', Validators.required],
      phoneNumber: ['', [Validators.required, Validators.pattern('^[0-9]{8}$')]],
      forfait: ['', Validators.required],
      forfaitInternet: ['', Validators.required],
      serialNumber: ['', Validators.required],
    });
  }

  ngOnInit(): void {
    this.loadEmployees();
  }

  loadEmployees(): void {
    this.employeeService.getAllEmployees().subscribe(
      (data) => {
        this.employees = data;
      },
      (error) => {
        console.error('Erreur de chargement des employés', error);
      }
    );
  }

  onSubmit(): void {
    if (this.assignForm.valid) {
      this.simService.assignSim(this.assignForm.value).subscribe(
        (response) => {
          if (response.success) {
            this.assignedData = response.sim; // Récupère les données de la SIM attribuée
            this.showModal = true; // Ouvre la modale
            alert('SIM attribuée avec succès !');
          } else {
            alert('Erreur : ' + response.message);
            console.log('Error:', response);
          }
        },
        (error) => {
          alert('Erreur : ' + error.message);
          console.error('Error:', error);
        }
      );
    }
  }

  // Méthode pour copier les données dans le presse-papiers
  copyToClipboard(): void {
    const data = `
      Employé : ${this.assignedData.employee.name}
      Numéro de téléphone : ${this.assignedData.phoneNumber}
      Forfait : ${this.assignedData.forfait}
      Forfait Internet : ${this.assignedData.forfaitInternet}
      Numéro de série : ${this.assignedData.serialNumber}
    `;
    navigator.clipboard.writeText(data).then(
      () => {
        alert('Données copiées dans le presse-papiers !');
      },
      (err) => {
        alert('Erreur lors de la copie : ' + err);
        console.error('Erreur de copie :', err);
      }
    );
  }
}
