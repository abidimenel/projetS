import mongoose from 'mongoose';

const employeeSchema = new mongoose.Schema({
  name: { type: String, required: true },
  cin: { type: String, required: true, unique: true },
  position: { type: String, required: true },
  department: { type: String, required: true },
  phoneNumber: { type: String },
  internetPlan: { type: String },
  simAssignedDate: { type: Date },
});

const Employee = mongoose.model('Employee', employeeSchema);

export default Employee;
