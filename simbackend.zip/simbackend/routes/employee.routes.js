import express from 'express';
import { createEmployee, getAllEmployees } from '../controllers/employee.controller.js';

const router = express.Router();

// Afficher tous les employés
router.get('/api/employees', getAllEmployees);

router.post('/api/employee', createEmployee);


export default router;
