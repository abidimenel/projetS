import express from 'express';
import Sim from '../models/sim.model.js'; // Import Sim Model
import Employee from '../models/employee.model.js';// Import Employee Model


const router = express.Router();

// Controller and route for adding a SIM
router.post('/sim', async (req, res) => {
  try {
      const { serialNumber, forfait, forfaitInternet } = req.body;

      // Vérification de l'existence de la SIM
      const existingSim = await Sim.findOne({ serialNumber });
      if (existingSim) {
        return res.status(400).json({ message: 'SIM already exists' });
      }

      // Création de la nouvelle SIM
      const sim = new Sim({
        serialNumber,
        forfait,
        forfaitInternet,
      });
      await sim.save();

      // Réponse avec la SIM créée
      res.status(201).json(sim);
    } catch (error) {
      res.status(500).json({ message: error.message });
    }
});

// Controller and route for assigning a SIM to an employee
router.post('/sim/assign', async (req, res) => {
    try {
        const { serialNumber, employeeId, phoneNumber, forfait, forfaitInternet } = req.body;
  
        // Fetch employee and SIM from the database
        const employee = await Employee.findById(employeeId);
        if (!employee) {
            return res.status(404).json({ success: false, message: 'Employé introuvable.' });
        }
  
        const sim = await Sim.findOne({ serialNumber });
        if (!sim) {
            return res.status(404).json({ success: false, message: 'SIM introuvable.' });
        }
  
        if (sim.assignedTo) {
            return res.status(400).json({ success: false, message: 'SIM déjà attribuée.' });
        }
  
        // Assigning the SIM to the employee
        sim.assignedTo = employee._id;
        sim.phoneNumber = phoneNumber;
        sim.forfait = forfait;
        sim.forfaitInternet = forfaitInternet;
        sim.assignedDate = new Date();
        await sim.save();
  
         // Fetching the employee's data to include in the response
        const assignedEmployee = await Employee.findById(employeeId)
        .select('name position department') // selecting name position and department from the employee
         // Respond with success message, updated SIM and employee
          res.status(200).json({
            success: true,
            message: 'SIM attribuée avec succès.',
            sim: sim,
            employee: assignedEmployee
        });
    } catch (error) {
        // Handling errors and return message
        res.status(500).json({ success: false, message: error.message });
    }
  });
  

// Controller and route for getting all SIMs
router.get('/sim', async (req, res) => {
  try {
      // Récupération de toutes les SIMs avec leurs informations d'employé
      const sims = await Sim.find().populate('assignedTo', 'name position department');
      res.status(200).json(sims);
    } catch (error) {
      res.status(500).json({ message: error.message });
    }
});

// Controller and route for assigning a number to a sim
router.post('/sim/assign-number', async (req, res) => {
  try {
    const { serialNumber, phoneNumber } = req.body;

    // Recherche de la SIM
    const sim = await Sim.findOne({ serialNumber });
    if (!sim) {
      return res.status(404).json({ message: 'SIM not found' });
    }

    // Attribution du numéro à la SIM
    sim.phoneNumber = phoneNumber;
    await sim.save();

    // Réponse avec la SIM mise à jour
    res.status(200).json(sim);
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
});

export default router;