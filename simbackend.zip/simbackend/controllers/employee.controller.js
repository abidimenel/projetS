import Employee from '../models/employee.model.js';

// Fonction pour récupérer tous les employés
export const getAllEmployees = async (req, res) => {
  try {
    const employees = await Employee.find();
    res.status(200).json(employees);
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
};
// Fonction pour créer un nouvel employé
export const createEmployee = async (req, res) => {
  try {
    const { name, cin, position, department, phoneNumber, internetPlan, simAssignedDate } = req.body;

    // Vérification de l'existence de l'employé avec le même CIN
    const existingEmployee = await Employee.findOne({ cin });
    if (existingEmployee) {
      return res.status(400).json({ message: 'L\'employé avec ce CIN existe déjà.' });
    }

    // Création de l'employé
    const employee = new Employee({
      name,
      cin,
      position,
      department,
      phoneNumber,
      internetPlan,
      simAssignedDate,
    });

    // Sauvegarde de l'employé
    await employee.save();

    // Réponse avec l'employé créé
    res.status(201).json(employee);
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
};
