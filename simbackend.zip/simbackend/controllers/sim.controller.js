import Sim from '../models/sim.model.js';
import Employee from '../models/employee.model.js';

// Fonction pour ajouter une SIM
export const createSim = async (req, res) => {
  try {
    const { serialNumber, forfait, forfaitInternet } = req.body;

    // Vérification de l'existence de la SIM
    const existingSim = await Sim.findOne({ serialNumber });
    if (existingSim) {
      return res.status(400).json({ message: 'SIM already exists' });
    }

    // Création de la nouvelle SIM
    const sim = new Sim({
      serialNumber,
      forfait,
      forfaitInternet,
    });
    await sim.save();

    // Réponse avec la SIM créée
    res.status(201).json(sim);
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
};

// Fonction pour attribuer une SIM à un employé
// Fonction pour attribuer une SIM à un employé
export const assignSim = async (req, res) => {
  try {
    const { serialNumber, employeeId, phoneNumber, forfait, forfaitInternet } = req.body;

    const employee = await Employee.findById(employeeId);
    if (!employee) {
      return res.status(404).json({ message: 'Employé introuvable.' });
    }

    const sim = await Sim.findOne({ serialNumber });
    if (!sim) {
      return res.status(404).json({ message: 'SIM introuvable.' });
    }

    if (sim.assignedTo) {
      return res.status(400).json({ message: 'SIM déjà attribuée.' });
    }

    sim.assignedTo = employee._id;
    sim.phoneNumber = phoneNumber;
    sim.forfait = forfait;
    sim.forfaitInternet = forfaitInternet;
    sim.assignedDate = new Date();
    await sim.save();

    res.status(200).json({ success: true, message: 'SIM attribuée avec succès.', sim });
  } catch (error) {
    handleErrors(res, error);
  }
};


// Fonction pour récupérer toutes les SIMs
export const getAllSims = async (req, res) => {
  try {
    // Récupération de toutes les SIMs avec leurs informations d'employé
    const sims = await Sim.find().populate('assignedTo', 'name position department');
    res.status(200).json(sims);
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
};

// Fonction pour attribuer un numéro à une SIM
export const assignSimNumber = async (req, res) => {
  try {
    const { serialNumber, phoneNumber } = req.body;

    // Recherche de la SIM
    const sim = await Sim.findOne({ serialNumber });
    if (!sim) {
      return res.status(404).json({ message: 'SIM not found' });
    }

    // Attribution du numéro à la SIM
    sim.phoneNumber = phoneNumber;
    await sim.save();

    // Réponse avec la SIM mise à jour
    res.status(200).json(sim);
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
};
