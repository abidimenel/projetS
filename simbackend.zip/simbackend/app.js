import express from 'express';
import mongoose from 'mongoose';
import cors from 'cors';
import dotenv from 'dotenv';
import simRoutes from './routes/sim.routes.js';
import employeeRoutes from './routes/employee.routes.js';
import authRoutes from './routes/auth.js';
dotenv.config();

const app = express();
const port = 5000;

// Middleware
app.use(cors({
  origin: 'http://localhost:4200', // Or your frontend's origin
  methods: ['GET', 'POST', 'PUT', 'DELETE'],
  allowedHeaders: ['Content-Type', 'Authorization'], // Add needed headers here
}));app.use(express.json());

// Routes


// Connexion à la base de données
mongoose
mongoose.connect('mongodb+srv://abidimenel4:KF1VGc4oz83JciYt@cluster0.wx1zn.mongodb.net/?retryWrites=true&w=majority&appName=Cluster0')

  .then(() => console.log('Database connected'))
  .catch((error) => console.error('Database connection error:', error));

  app.use('/api', simRoutes);
  app.use('/api/auth', authRoutes);
  app.use(employeeRoutes);


// Lancer le serveur
app.listen(port, () => {
  console.log(`Server running on port ${port}`);
});
